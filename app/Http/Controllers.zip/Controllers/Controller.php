<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use App\User;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function admin(){
        return view('admin');
    }

    public  function resizeImage($filename,$h,$target=null){
        $filename = storage_path('app/').$filename;



        // Get new dimensions
        list($width, $height) = getimagesize($filename);
        $new_height = $h;
        $new_width = $width/$height * $h;

        // Resample
        $image_p = imagecreatetruecolor($new_width, $new_height);
        $image = imagecreatefromjpeg($filename);
        imagecopyresampled($image_p, $image, 0, 0, 0, 0, $new_width, $new_height, $width, $height);

        // Output
        if($target==null){
            imagejpeg($image_p,$filename,100);
        }
        else{
            imagejpeg($image_p,$target,100);
        }

    }

    public function deleteUser(User $user){
        $user->delete();
        return back();
    }
}
