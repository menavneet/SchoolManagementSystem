<footer style="background:#222;color:white">
<div class="container">
  <div class="row text-right">
    <div class="col-sm-4">
      <p><i class="fa fa-map-o fa-2x" aria-hidden="true"></i></p>
      <p>M.P. Birla Shiksha Bhawan & Inter College,<br> Chhatnag, Jhusi, Allahabad</p>
      <p>211019</p>
    </div>
    <div class="col-sm-4">
      <p><i class="fa fa-phone fa-2x" aria-hidden="true"></i></p>
      <p>+91-(0532)-2567265</p>
      <p> +91-945-539-8673</p>
    </div>
    <div class="col-sm-4">
      <p><i class="fa fa-2x fa-envelope" aria-hidden="true"></i> </p>
      <p>contactl@mpbirlaschool.org</p>
      <p>principal@mpbirlaschool.org </p>
    </div>
  </div>
</div>
</footer>
</div>