<style>
        .sub-item{
                background-color:#0092bc;
                color:white !important;
        }
        .sub-item:hover{
                cursor:pointer;
                background-color:#22a2cc !important;
                color:white !important;

        }
</style>

<div class="list-group">
        <a href="/register" class="list-group-item sub-item"> Admin</a>
        <a class="list-group-item sub-item" data-toggle="collapse"  data-target="#content-manager"><i class="fa fa-angle-double-right fa-lg pull-right" aria-hidden="true"></i> Content Manage</a>
        <div class="collapse" id="content-manager">
                <a href="/admin/Banner" class="list-group-item"> Banner</a>
                <a href="/admin/Download" class="list-group-item"> Download</a>
                <a href="/admin/Menu" class="list-group-item"> Menu | Section</a>
                <a href="/admin/Page" class="list-group-item"> Page</a>
                <a href="/admin/Birthday" class="list-group-item"> Birthday</a>
                <a href="/admin/News" class="list-group-item"> News</a>
                <a href="/admin/Topper" class="list-group-item"> Topper</a>
                <a href="/admin/Gallery" class="list-group-item"> Gallery</a>
                <a href="/admin/Photo" class="list-group-item"> Photo</a>
        </div>
        <a class="list-group-item sub-item" data-toggle="collapse"  data-target="#master-record"><i class="fa fa-angle-double-right fa-lg pull-right" aria-hidden="true"></i> Master Record</a>
        <div class="collapse" id="master-record">
                <a href="" class="list-group-item">Session</a>
                <a href="" class="list-group-item">State</a>
                <a href="" class="list-group-item">Session</a>
                <a href="" class="list-group-item">Category</a>                
                <a href="" class="list-group-item">Class</a>
                <a href="" class="list-group-item">Section</a>
                <a href="" class="list-group-item">Subject Type</a>
                <a href="" class="list-group-item">Subject</a>
                <a href="" class="list-group-item">Subject Mapping</a>                                
        </div>
        <a class="list-group-item sub-item" data-toggle="collapse"  data-target="#student"><i class="fa fa-angle-double-right fa-lg pull-right" aria-hidden="true"></i> Student</a>
        <div class="collapse" id="student">
                <a href="" class="list-group-item">Registartion</a>
                <a href="" class="list-group-item">Detail</a>
                <a href="" class="list-group-item">Report</a>
                <a href="" class="list-group-item">Re-Registration</a>                
                <a href="" class="list-group-item">Idendity Card</a>
                <a href="" class="list-group-item">Transfer Certificate</a>
                <a href="" class="list-group-item">Certificate</a>                         
        </div>
        <a class="list-group-item sub-item" data-toggle="collapse"  data-target="#attendence"><i class="fa fa-angle-double-right fa-lg pull-right" aria-hidden="true"></i> Attendence</a>
        <div class="collapse" id="attendence">
                <a href="" class="list-group-item">Student Attendence</a>
                <a href="" class="list-group-item">Attendence SMS</a>
                <a href="" class="list-group-item">Attendence Detail Report</a>
                <a href="" class="list-group-item">Attendence Report</a>                                              
        </div>
        <a class="list-group-item sub-item" data-toggle="collapse"  data-target="#sms"><i class="fa fa-angle-double-right fa-lg pull-right" aria-hidden="true"></i> SMS</a>
        <div class="collapse" id="sms">
                <a href="" class="list-group-item">SMS Template</a>
                <a href="" class="list-group-item">Student SMS</a>
                <a href="" class="list-group-item">Staff SMS</a>
                <a href="" class="list-group-item">Birthday SMS</a>                
                <a href="" class="list-group-item">Show SMS</a>
                <a href="" class="list-group-item">Other SMS</a>
                <a href="" class="list-group-item">Send SMS</a>
                <a href="" class="list-group-item">Student SMS Report</a>
                <a href="" class="list-group-item">Staff SMS Report</a>                                
                <a href="" class="list-group-item">Other SMS Report</a>                                
        </div> 
        <a class="list-group-item sub-item" data-toggle="collapse"  data-target="#fee"><i class="fa fa-angle-double-right fa-lg pull-right" aria-hidden="true"></i> Fee</a>
        <div class="collapse" id="fee">
                <a href="" class="list-group-item">Fees Master</a>
                <a href="" class="list-group-item">Fees Setting</a>
                <a href="" class="list-group-item">Fees Mapping</a>
                <a href="" class="list-group-item">Fees Reciept</a>                
                <a href="" class="list-group-item">Paid Fees Report</a>
                <a href="" class="list-group-item">Unpaid Fees Report</a>                           
        </div>
        <a class="list-group-item sub-item" data-toggle="collapse"  data-target="#examination"><i class="fa fa-angle-double-right fa-lg pull-right" aria-hidden="true"></i> Examination</a>
        <div class="collapse" id="examination">
                <a href="" class="list-group-item">Examination Master</a>
                <a href="" class="list-group-item">Marks Master</a>
                <a href="" class="list-group-item">Marks Entry</a>
                <a href="" class="list-group-item">Grade Master</a>                
                <a href="" class="list-group-item">Examination Report Card</a>
                <a href="" class="list-group-item">Examination Report</a>                           
        </div>                  
        
</div> 