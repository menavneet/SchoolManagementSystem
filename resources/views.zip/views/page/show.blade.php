@extends('layout.main')
@section('content')
    {!!$page->content!!}
@endsection