@extends('layout.admin')
@section('content')
    <h1>Admin Dashboard</h1>
@endsection